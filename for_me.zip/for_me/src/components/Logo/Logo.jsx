import React from 'react';
// import './sass/logo.sass'

function Logo() {
  return(
    <div >
      <a href="#">
        <img src="../../img/navLogo.svg" alt="" height="27.5" width="128.5"/>
      </a>
    </div>
  )
}

export default Logo
